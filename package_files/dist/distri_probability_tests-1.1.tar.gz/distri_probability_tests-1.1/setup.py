from setuptools import setup

setup(name='distri_probability_tests',
      version='1.1',
      description='Gaussian distributions',
      packages=['distri_probability_tests'],
      author = 'Miguel',
      author_email = 'name@gmail.com',
      zip_safe=False)
